Per non compromettere il comportamento 
di Arduino il video � stato ripreso da
lontano con zoom e flash attivi 
compromettendone la qualit�. Per motivi di chiarezza 
elenco in seguito le azioni fatte eseguire ad Arduino. 
Single mode, single mode velocizzata, manual mode e auto mode.