<?php
include 'db_helper.php';
toggle_avail();
header("Location:index.php");
?>